import importlib.metadata
__version__ = importlib.metadata.version('camel-xml2dsl')