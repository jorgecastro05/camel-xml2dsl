# XML to DSL route

## Installing the script:

    pip install camel_xml2dsl-0.0.1-py3-none-any.whl --force-reinstall

## Running the script

    xml2dsl --xml xml_context_file.xml

## Building the project (for developers)

    python -m build
    
build and install

    python -m build && pip install dist/camel_xml2dsl-0.0.1-py3-none-any.whl --force-reinstall

