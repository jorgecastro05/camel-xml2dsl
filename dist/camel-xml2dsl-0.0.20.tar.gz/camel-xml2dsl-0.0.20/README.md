# XML to DSL route

![Image!](https://i.imgur.com/rlcS3pw.png)

## Installing the script:

    pip install camel_xml2dsl-0.0.x-py3-none-any.whl

Where x belongs to release version

## Running the script

    xml2dsl --xml xml_context_file.xml

## Building the project (for developers)

### Install dependencies
    
    python3 -m pip install --upgrade build
    python -m build
    
build and install

    python -m build && pip install dist/camel_xml2dsl-0.0.1-py3-none-any.whl --force-reinstall

