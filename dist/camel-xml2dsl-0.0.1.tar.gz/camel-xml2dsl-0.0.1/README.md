# XML to DSL route

## Installing the script:

    pip install camel_xml2dsl-0.0.1-py3-none-any.whl --force-reinstall

## Running the script

    xml2dsl --xml xml_context_file.xml

## Building the project

    python -m build

